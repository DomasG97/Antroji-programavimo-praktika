﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{
    class GroupsRepository
    {
        private SqlConnection conn;
        public GroupsRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public List<Group> GetGroups()
        {
            LecturesRepository lrepository = new LecturesRepository();
            StudentsRepository srepository = new StudentsRepository();

            List<Group> groupsList = new List<Group>();

            try
            {
                string sql = "select GroupID, Title from Groups";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int GroupID = int.Parse(reader["GroupID"].ToString());
                        string Title = reader["Title"].ToString();

                        groupsList.Add(new Group(GroupID, Title));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            foreach (Group group in groupsList)
                group.SetLectures(lrepository.GetLectures(group.GroupID));

            foreach (Group group in groupsList)
                group.SetStudents(srepository.GetStudents(group.GroupID));

            return groupsList;
        }

        public List<Group> GetLecturerGroups(int lectureid)
        {
            StudentsRepository repository = new StudentsRepository();

            List<Group> groupsList = new List<Group>();

            try
            {
                string sql = "select GroupID, Title from Groups" +
                    " where GroupID in" +
                    " (select GroupID from Lectures where LectureID=@LectureID)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("LectureID", lectureid);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int GroupID = int.Parse(reader["GroupID"].ToString());
                        string Title = reader["Title"].ToString();

                        groupsList.Add(new Group(GroupID, Title));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            foreach (Group group in groupsList)
                group.SetStudents(repository.GetStudents(group.GroupID));

            return groupsList;
        }

        public void AddGroup(string title)
        {
            try
            {
                string sql = "insert into Groups (Title)" +
                    " values (@Title)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", title);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveGroup(string title)
        {
            try
            {
                string sql = "delete from Groups" +
                    " where Title=@Title";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", title);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
