﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{
    class UsersRepository
    {
        private SqlConnection conn;

        public UsersRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public User GetUser(string username, string password)
        {
            try
            {
                string sql = "select UserID, Username, Password, Status from Users" +
                " where Username=@Username and Password=@Password";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int UserID = int.Parse(reader["UserID"].ToString());
                        string Username = reader["Username"].ToString();
                        string Password = reader["Password"].ToString();
                        string Status = reader["Status"].ToString();
                        return new User(UserID, Username, Password, Status);
                    }
                }
                conn.Close();
                throw new Exception("Neteisingas prisijungimo vardas arba slaptažodis.");
            }
            catch(Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public Admin GetAdmin(int userid)
        {            
            try
            {
                string sql = "select AdminID, Name, Surname from Admins" +
                    " where UserID=@UserID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("UserID", userid);
                //conn.Open();
                using(conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;"))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    conn.Open();
                    while (reader.Read())
                    {
                        int AdminID = int.Parse(reader["AdminID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();
                        return new Admin(AdminID, Name, Surname);
                    }
                }
                //conn.Close();
                throw new Exception("Database error.");
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public Lecturer GetLecturer(int userid)
        {
            try
            {
                string sql = "select LecturerID, UserID, LectureID, Name, Surname from Lecturers" +
                    " where UserID=@UserID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("UserID", userid);
                using (conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;"))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    conn.Open();
                    while (reader.Read())
                    {
                        int LecturerID = int.Parse(reader["LecturerID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();
                        return new Lecturer(LecturerID, UserID, LectureID, Name, Surname);
                    }
                }
                throw new Exception("Database error.");
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public Student GetStudent(int userid)
        {
            try
            {
                string sql = "select StudentID, UserID, GroupID, Name, Surname from Students" +
                    " where UserID=@UserID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("UserID", userid);
                using (conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;"))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    conn.Open();
                    while (reader.Read())
                    {
                        int StudentID = int.Parse(reader["StudentID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int GroupID = int.Parse(reader["GroupID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();
                        return new Student(StudentID, UserID, GroupID, Name, Surname);
                    }
                }
                throw new Exception("Database error.");
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
        
        public void AddUser(string username, string password, string status)
        {
            try
            {
                string sql = "insert into Users (Username, Password, Status)" +
                    " values (@Username, @Password, @Status)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@Status", status);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveUser(int userid)
        {
            try
            {
                string sql = "delete from Users" +
                    " where UserID=@UserID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@UserID", userid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
