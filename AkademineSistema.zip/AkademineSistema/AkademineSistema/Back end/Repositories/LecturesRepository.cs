﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{
    public class LecturesRepository
    {
        private SqlConnection conn;

        public LecturesRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public List<Lecture> GetLectures(int groupid)
        {
            List<Lecture> lecturesList = new List<Lecture>();
            try
            {
                string sql = "select LectureID, Title from Lectures" +
                    " where GroupID=@GroupID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("GroupID", groupid);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        string Title = reader["Title"].ToString();
                        lecturesList.Add(new Lecture(LectureID, Title));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
            return lecturesList;
        }

        public Lecture GetLecturerLecture(int lectureid)
        {
            string sql = "select LectureID, Title from Lectures" +
                " where LectureID=@LectureID";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("LectureID", lectureid);
            conn.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int LectureID = int.Parse(reader["LectureID"].ToString());
                    string Title = reader["Title"].ToString();

                    return new Lecture(LectureID, Title);
                }
            }
            conn.Close();

            return null;
        }

        public void AddLecture(int groupid, string title)
        {
            try
            {
                string sql = "insert into Lectures (GroupID, Title)" +
                    " values (@GroupID, @Title)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@GroupID", groupid);
                cmd.Parameters.AddWithValue("@Title", title);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveLecture(int lectureid)
        {
            try
            {
                string sql = "delete from Lectures" +
                    " where LectureID=@LectureID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@LectureID", lectureid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
