﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{   
    public class StudentsRepository
    {
        private SqlConnection conn;
        
        public StudentsRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public List<Student> GetStudents(int groupid)
        {
            List<Student> studentsList = new List<Student>();
            try
            {
                string sql = "select StudentID, UserID, GroupID, Name, Surname from Students" +
                    " where GroupID=@GroupID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("GroupID", groupid);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int StudentID = int.Parse(reader["StudentID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int GroupID = int.Parse(reader["GroupID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();
                        studentsList.Add(new Student(StudentID, UserID, GroupID, Name, Surname));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
            return studentsList;
        }

        public void AddStudent(int userid, int groupid, string name, string surname)
        {
            try
            {
                string sql = "insert into Students (UserID, GroupID, Name, Surname)" +
                    " values (@UserID, @GroupID, @Name, @Surname)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@UserID", userid);
                cmd.Parameters.AddWithValue("@GroupID", groupid);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Surname", surname);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveStudent(int studentid)
        {
            try
            {
                string sql = "delete from Students" +
                    " where StudentID=@StudentID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@StudentID", studentid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
