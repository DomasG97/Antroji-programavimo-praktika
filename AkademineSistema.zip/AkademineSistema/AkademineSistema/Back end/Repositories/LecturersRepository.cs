﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{
    public class LecturersRepository
    {
        private SqlConnection conn;
        
        public LecturersRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public List<Lecturer> GetLecturers()
        {
            List<Lecturer> lecturersList = new List<Lecturer>();
            
            try
            {
                string sql = "select LecturerID, UserID, LectureID, Name, Surname from Lecturers";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                //using(conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;"))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    //conn.Open();
                    while (reader.Read())
                    {
                        int LecturerID = int.Parse(reader["LecturerID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();

                        lecturersList.Add(new Lecturer(LecturerID, UserID, LectureID, Name, Surname));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            return lecturersList;
        }

        public Lecturer GetLecturer(int lecturerid)
        {
            try
            {
                string sql = "select LecturerID, UserID, LectureID, Name, Surname from Lecturers" +
                " where LecturerID=@LecturerID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("LecturerID", lecturerid);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    conn.Open();
                    while (reader.Read())
                    {
                        int LecturerID = int.Parse(reader["LecturerID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();

                        return new Lecturer(LecturerID, UserID, LectureID, Name, Surname);
                    }
                }
                conn.Close();
            }
            catch(Exception exc)
            {
                throw new Exception(exc.Message);
            }

            return null;
        }

        public Lecturer GetLecturerByLecture(int lectureid)
        {            
            try
            {
                string sql = "select LecturerID, UserID, LectureID, Name, Surname from Lecturers" +
                " where LectureID=@LectureID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("LectureID", lectureid);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int LecturerID = int.Parse(reader["LecturerID"].ToString());
                        int UserID = int.Parse(reader["UserID"].ToString());
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        string Name = reader["Name"].ToString();
                        string Surname = reader["Surname"].ToString();

                        return new Lecturer(LecturerID, UserID, LectureID, Name, Surname);
                    }
                }
                conn.Close();
            }
            catch(Exception exc)
            {
                throw new Exception(exc.Message);
            }

            return null;
        }

        public void AddLecturer(int userid, string name, string surname)
        {
            try
            {
                string sql = "insert into Lecturers (UserID, LectureID, Name, Surname)" +
                    " values (@UserID, @LectureID, @Name, @Surname)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@UserID", userid);
                cmd.Parameters.AddWithValue("@LectureID", 0);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Surname", surname);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveLecturer(int lecturerid)
        {
            try
            {
                string sql = "delete from Lecturers" +
                    " where LecturerID=@LecturerID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@LecturerID", lecturerid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void UpdateLectureID(int lecturerid, int lectureid)
        {
            try
            {
                string sql = "update Lecturers set LectureID=@LectureID" +
                    " where LecturerID=@LecturerID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@LectureID", lectureid);
                cmd.Parameters.AddWithValue("@LecturerID", lecturerid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
