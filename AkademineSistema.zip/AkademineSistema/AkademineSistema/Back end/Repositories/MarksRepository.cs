﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AkademineSistema
{
    public class MarksRepository
    {
        private SqlConnection conn;
        
        public MarksRepository()
        {
            conn = new SqlConnection(@"Server=.;Database=AkademineSistema_DB;Integrated Security=true;");
        }

        public List<Mark> GetMarks(int studentid, int lectureid)
        {
            List<Mark> marksList = new List<Mark>();
            try
            {
                string sql = "select Mark, StudentID, LectureID from Marks" +
                    " where StudentID=@StudentID and LectureID=@LectureID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("StudentID", studentid);
                cmd.Parameters.AddWithValue("LectureID", lectureid);

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int Value = int.Parse(reader["Mark"].ToString());
                        int StudentID = int.Parse(reader["StudentID"].ToString());
                        int LectureID = int.Parse(reader["LectureID"].ToString());
                        marksList.Add(new Mark(Value, StudentID, LectureID));
                    }
                }
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
            return marksList;
        }

        public void AddMark(int mark, int lectureid, int studentid)
        {
            try
            {
                string sql = "insert into Marks (Mark, LectureID, StudentID)" +
                    " values (@Mark, @LectureID, @StudentID)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Mark", mark);
                cmd.Parameters.AddWithValue("@LectureID", lectureid);
                cmd.Parameters.AddWithValue("@StudentID", studentid);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void RemoveMark(int mark)
        {
            try
            {
                string sql = "delete top (1) from Marks" +
                    " where Mark=@Mark";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Mark", mark);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }
    }
}
