﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Group
    {
        public int GroupID;
        public string Title;
        public List<Lecture> lecturesList { get; private set; }
        public List<Student> studentsList { get; private set; }
        public Group(int groupid, string title)
        {
            GroupID = groupid;
            Title = title;
        }

        public void SetLectures(List<Lecture> lectures)
        {
            lecturesList = lectures;
        }

        public void SetStudents(List<Student> students)
        {
            studentsList = students;
        }
    }
}
