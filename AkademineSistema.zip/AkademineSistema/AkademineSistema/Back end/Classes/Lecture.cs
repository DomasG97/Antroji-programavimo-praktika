﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Lecture
    {
        public int LectureID;
        public string Title;

        public Lecture(int lectureid, string title)
        {
            LectureID = lectureid;
            Title = title;
        }
    }
}
