﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Student
    {
        public int StudentID;
        public int UserID;
        public int GroupID;
        public string Name;
        public string Surname;
        public List<Mark> Marks { get; private set; }
        public Student(int studentid, int userid, int groupid, string name, string surname)
        {
            StudentID = studentid;
            UserID = userid;
            GroupID = groupid;
            Name = name;
            Surname = surname;
        }

        public int GetStudentID()
        {
            return StudentID;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetSurname()
        {
            return Surname;
        }
    }
}
