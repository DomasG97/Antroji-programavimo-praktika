﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class User
    {
        int UserID;
        string Username;
        string Password;
        string Status;
        public User(int userid, string username, string password, string status)
        {
            UserID = userid;
            Username = username;
            Password = password;
            Status = status;
        }

        public int GetUserID()
        {
            return UserID;
        }

        public string GetUsername()
        {
            return Username;
        }

        public string GetPassword()
        {
            return Password;
        }

        public string GetStatus()
        {
            return Status;
        }
    }
}
