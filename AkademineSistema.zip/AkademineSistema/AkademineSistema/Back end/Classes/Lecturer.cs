﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Lecturer
    {
        public int LecturerID;
        public int UserID;
        public int LectureID;
        public string Name;
        public string Surname;
        
        public Lecturer(int lecturerid, int userid, int lectureid, string name, string surname)
        {
            LecturerID = lecturerid;
            UserID = userid;
            LectureID = lectureid;
            Name = name;
            Surname = surname;
        }

        public int GetLecturerID()
        {
            return LecturerID;
        }

        public int GetLectureID()
        {
            return LectureID;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetSurname()
        {
            return Surname;
        }
    }
}
