﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Mark
    {
        public int Value;
        public int StudentID;
        public int LectureID;
        public Mark(int value, int studentid, int lectureid)
        {
            Value = value;
            StudentID = studentid;
            LectureID = lectureid;
        }
    }
}
