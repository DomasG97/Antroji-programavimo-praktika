﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Admin
    {
        public int AdminID;
        public string Name;
        public string Surname;
        
        public Admin(int adminid, string name, string surname)
        {
            AdminID = adminid;
            Name = name;
            Surname = surname;
        }

        public int GetAdminID()
        {
            return AdminID;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetSurname()
        {
            return Surname;
        }
    }
}
