﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AkademineSistema
{
    public class Person
    {
        public string Name;
        public string Surname;
        public string Status;

        public Person(string name, string surname, string status)
        {
            Name = name;
            Surname = surname;
            Status = status;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetSurname()
        {
            return Surname;
        }

        public string GetStatus()
        {
            return Status;
        }
    }
}
