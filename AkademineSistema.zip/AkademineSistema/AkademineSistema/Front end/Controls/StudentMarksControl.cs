﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class StudentMarksControl : UserControl
    {
        MarksRepository repository = new MarksRepository();
        
        public StudentMarksControl(string title, int lectureid, int studentid)
        {
            InitializeComponent();
            lectureLabel.Text = title;

            List<Mark> marksList = repository.GetMarks(studentid, lectureid);

            foreach(Mark mark in marksList)
            {
                StudentMarkControl smc = new StudentMarkControl(mark.Value);

                marksLayoutPanel.Controls.Add(smc);
            }
        }
    }
}
