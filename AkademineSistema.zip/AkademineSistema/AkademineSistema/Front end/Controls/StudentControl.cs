﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class StudentControl : UserControl
    {
        UsersRepository urepository = new UsersRepository();
        StudentsRepository srepository = new StudentsRepository();
        Student student;
        
        public StudentControl(Student student)
        {
            InitializeComponent();
            studentLabel.Text = student.Name + " " + student.Surname;

            this.student = student;
        }

        private void removeStudentButton_Click(object sender, EventArgs e)
        {
            urepository.RemoveUser(student.UserID);
            srepository.RemoveStudent(student.StudentID);

            MessageBox.Show("Studentas ištrintas.");
        }
    }
}
