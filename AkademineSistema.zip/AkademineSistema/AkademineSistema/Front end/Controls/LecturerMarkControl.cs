﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class LecturerMarkControl : UserControl
    {
        MarksRepository repository = new MarksRepository();
        int mark;
        
        public LecturerMarkControl(int mark)
        {
            InitializeComponent();

            this.mark = mark;
            markLabel.Text = mark.ToString();
        }

        private void deleteMarkButton_Click(object sender, EventArgs e)
        {
            repository.RemoveMark(mark);

            MessageBox.Show("Pažymys ištrintas.");
        }
    }
}
