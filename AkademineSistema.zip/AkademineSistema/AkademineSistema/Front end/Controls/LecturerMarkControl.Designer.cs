﻿namespace AkademineSistema
{
    partial class LecturerMarkControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.markLabel = new System.Windows.Forms.Label();
            this.deleteMarkButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // markLabel
            // 
            this.markLabel.Location = new System.Drawing.Point(3, 0);
            this.markLabel.Name = "markLabel";
            this.markLabel.Size = new System.Drawing.Size(64, 19);
            this.markLabel.TabIndex = 0;
            this.markLabel.Text = "mark";
            this.markLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // deleteMarkButton
            // 
            this.deleteMarkButton.Location = new System.Drawing.Point(23, 22);
            this.deleteMarkButton.Name = "deleteMarkButton";
            this.deleteMarkButton.Size = new System.Drawing.Size(25, 25);
            this.deleteMarkButton.TabIndex = 1;
            this.deleteMarkButton.Text = "X";
            this.deleteMarkButton.UseVisualStyleBackColor = true;
            this.deleteMarkButton.Click += new System.EventHandler(this.deleteMarkButton_Click);
            // 
            // MarkControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.deleteMarkButton);
            this.Controls.Add(this.markLabel);
            this.Name = "MarkControl";
            this.Size = new System.Drawing.Size(70, 50);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label markLabel;
        private System.Windows.Forms.Button deleteMarkButton;
    }
}
