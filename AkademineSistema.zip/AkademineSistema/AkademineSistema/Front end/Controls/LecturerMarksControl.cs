﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class LecturerMarksControl : UserControl
    {
        MarksRepository repository = new MarksRepository();
        Student student;
        int LectureID;

        public LecturerMarksControl(Student student, int lectureid)
        {
            InitializeComponent();

            studentLabel.Text = student.Name + " " + student.Surname;

            this.student = student;
            LectureID = lectureid;

            List<Mark> marksList = repository.GetMarks(student.StudentID, lectureid);

            foreach (Mark mark in marksList)
            {
                LecturerMarkControl lmc = new LecturerMarkControl(mark.Value);

                marksLayoutPanel.Controls.Add(lmc);
            }
        }

        private void addMarkButton_Click(object sender, EventArgs e)
        {
            AddMarkWindow form = new AddMarkWindow(LectureID, student.StudentID);
            form.ShowDialog();
        }
    }
}
