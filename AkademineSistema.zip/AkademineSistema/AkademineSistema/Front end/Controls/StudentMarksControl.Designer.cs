﻿namespace AkademineSistema
{
    partial class StudentMarksControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.marksLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lectureLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // marksLayoutPanel
            // 
            this.marksLayoutPanel.AutoScroll = true;
            this.marksLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.marksLayoutPanel.Location = new System.Drawing.Point(260, 4);
            this.marksLayoutPanel.Name = "marksLayoutPanel";
            this.marksLayoutPanel.Size = new System.Drawing.Size(687, 63);
            this.marksLayoutPanel.TabIndex = 0;
            // 
            // lectureLabel
            // 
            this.lectureLabel.AutoSize = true;
            this.lectureLabel.Location = new System.Drawing.Point(14, 14);
            this.lectureLabel.MaximumSize = new System.Drawing.Size(240, 0);
            this.lectureLabel.Name = "lectureLabel";
            this.lectureLabel.Size = new System.Drawing.Size(85, 17);
            this.lectureLabel.TabIndex = 1;
            this.lectureLabel.Text = "lecture label";
            // 
            // StudentMarksControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.lectureLabel);
            this.Controls.Add(this.marksLayoutPanel);
            this.Name = "StudentMarksControl";
            this.Size = new System.Drawing.Size(950, 70);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel marksLayoutPanel;
        private System.Windows.Forms.Label lectureLabel;
    }
}
