﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AdminWindow : LoggedInWindow
    {
        LecturersRepository lrepository = new LecturersRepository();
        GroupsRepository grepository = new GroupsRepository();
        List<Lecturer> lecturersList;
        List<Group> groupsList;
        Button lecturerButton;
        Button groupButton;
        Lecturer lecturer;
        Group group;

        public AdminWindow(Admin admin) : base()
        {
            InitializeComponent();

            nameLabel.Text = admin.GetName();
            surnameLabel.Text = admin.GetSurname();

            SetLecturersValues();
            SetGroupsValues();
        }

        public void SetLecturersValues()
        {
            lecturersLayoutPanel.Controls.Clear();

            lecturersList = lrepository.GetLecturers();

            int buttonWidth = lecturersLayoutPanel.Width - 10;

            foreach (Lecturer lecturer in lecturersList)
            {
                Button lecturerButton = new Button();
                lecturerButton.Text = "ID-" + lecturer.LecturerID + "   " + lecturer.Name + " " + lecturer.Surname;
                lecturerButton.Width = buttonWidth;
                lecturerButton.AutoSize = true;
                lecturerButton.Tag = lecturer;
                lecturerButton.Click += LecturerButton_Click;
                lecturersLayoutPanel.Controls.Add(lecturerButton);
            }
        }
        
        public void SetGroupsValues()
        {
            groupsLayoutPanel.Controls.Clear();

            groupsList = grepository.GetGroups();

            int buttonWidth = groupsLayoutPanel.Width - 10;

            foreach (Group group in groupsList)
            {
                Button groupButton = new Button();
                groupButton.Text = group.Title;
                groupButton.Width = buttonWidth;
                groupButton.Tag = group;
                groupButton.Click += GroupButton_Click;
                groupsLayoutPanel.Controls.Add(groupButton);
            }
        }

        private void SetLecturesValues()
        {
            lecturesLayoutPanel.Controls.Clear();

            addLectureButton.Visible = true;
            removeLectureButton.Visible = true;

            int buttonWidth = lecturesLayoutPanel.Width - 10;

            foreach (Lecture lecture in group.lecturesList)
            {
                Button lectureButton = new Button();
                lectureButton.Text = "ID-" + lecture.LectureID + "   " + lecture.Title;
                lectureButton.Width = buttonWidth;
                lectureButton.AutoSize = true;
                lectureButton.Tag = lecture;
                lectureButton.Click += LectureButton_Click;
                lecturesLayoutPanel.Controls.Add(lectureButton);
            }
        }

        public void SetStudentsValues()
        {
            studentsLayoutPanel.Controls.Clear();

            addStudentButton.Visible = true;

            foreach (Student student in group.studentsList)
            {
                StudentControl sc = new StudentControl(student);
                studentsLayoutPanel.Controls.Add(sc);
            }
        }

        private void LecturerButton_Click(object sender, EventArgs e)
        {
            lecturerButton = (Button)sender;
            lecturer = (Lecturer)lecturerButton.Tag;

            LecturerInfoWindow form = new LecturerInfoWindow(lecturer);
            form.ShowDialog();
        }

        private void GroupButton_Click(object sender, EventArgs e)
        {
            groupButton = (Button)sender;
            group = (Group)groupButton.Tag;

            SetLecturesValues();
            SetStudentsValues();
        }

        private void LectureButton_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Lecture lecture = (Lecture)button.Tag;

            LectureWindow form = new LectureWindow(lecture.Title, lecture.LectureID);
            form.ShowDialog();
        }

        private void addGroupButton_Click(object sender, EventArgs e)
        {
            AddGroupWindow form = new AddGroupWindow(groupsList);
            form.ShowDialog();
            SetGroupsValues();
        }

        private void addStudentButton_Click(object sender, EventArgs e)
        {
            AddStudentWindow form = new AddStudentWindow(group.GroupID);
            form.ShowDialog();
            SetGroupsValues();
        }

        private void removeGroupButton_Click(object sender, EventArgs e)
        {
            RemoveGroupWindow form = new RemoveGroupWindow(groupsList);
            form.ShowDialog();
            SetGroupsValues();
        }

        private void addLectureButton_Click(object sender, EventArgs e)
        {
            AddLectureWindow form = new AddLectureWindow(group.GroupID);
            form.ShowDialog();
        }

        private void removeLectureButton_Click(object sender, EventArgs e)
        {
            RemoveLectureWindow form = new RemoveLectureWindow(group.lecturesList);
            form.ShowDialog();
        }

        private void addLecturerButton_Click(object sender, EventArgs e)
        {
            AddLecturerWindow form = new AddLecturerWindow();
            form.ShowDialog();
            SetLecturersValues();
        }

        private void removeLecturerButton_Click(object sender, EventArgs e)
        {
            RemoveLecturerWindow form = new RemoveLecturerWindow(lecturersList);
            form.ShowDialog();
            SetLecturersValues();
        }
    }
}
