﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AddLectureWindow : Form
    {
        LecturesRepository repository = new LecturesRepository();
        int GroupID;
        
        public AddLectureWindow(int groupid)
        {
            InitializeComponent();

            GroupID = groupid;
        }

        private void addLectureButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(lectureTextBox.Text))
                    throw new Exception("Paskaita neįvesta. Įveskite paskaitą.");
                else
                {
                    repository.AddLecture(GroupID, lectureTextBox.Text);

                    MessageBox.Show("Paskaita pridėta.");
                    this.Close();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
