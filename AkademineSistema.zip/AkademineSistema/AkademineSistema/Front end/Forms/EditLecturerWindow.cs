﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class EditLecturerWindow : Form
    {
        LecturersRepository repository = new LecturersRepository();
        Lecturer lecturer;
        int LectureID;
        
        public EditLecturerWindow(int lectureid, Lecturer lecturer)
        {
            InitializeComponent();

            LectureID = lectureid;
            this.lecturer = lecturer;
        }

        private void saveLecturerButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(lecturerIDTextBox.Text))
                    throw new Exception("Dėstytojo ID neįvestas.");
                else
                {
                    if (lecturer != null)
                    {
                        repository.UpdateLectureID(lecturer.LecturerID, 0);
                    }

                    repository.UpdateLectureID(int.Parse(lecturerIDTextBox.Text), LectureID);

                    MessageBox.Show("Pakeitimai išsaugoti.");
                    this.Close();
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
