﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class StudentWindow : LoggedInWindow
    {
        LecturesRepository repository = new LecturesRepository();

        public StudentWindow(Student student) : base()
        {
            InitializeComponent();
            nameLabel.Text = student.GetName();
            surnameLabel.Text = student.GetSurname();

            List<Lecture> lecturesList = repository.GetLectures(student.GroupID);

            foreach(Lecture lecture in lecturesList)
            {
                StudentMarksControl smc = new StudentMarksControl(lecture.Title, lecture.LectureID, student.StudentID);
                
                marksLayoutPanel.Controls.Add(smc);
            }
        }
    }
}
