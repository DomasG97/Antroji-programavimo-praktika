﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AddMarkWindow : Form
    {
        MarksRepository repository = new MarksRepository();
        int LectureID, StudentID;
        
        public AddMarkWindow(int lectureid, int studentid)
        {
            InitializeComponent();

            LectureID = lectureid;
            StudentID = studentid;
        }

        private void addMarkButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(markTextBox.Text))
                    throw new Exception("Įveskite pažymį.");
                else
                {
                    repository.AddMark(int.Parse(markTextBox.Text), LectureID, StudentID);

                    MessageBox.Show("Pažymys įrašytas.");
                    this.Close();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
