﻿namespace AkademineSistema
{
    partial class AddLecturerWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lecturerNameTextBox = new System.Windows.Forms.TextBox();
            this.lecturerSurnameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addLecturerButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lecturerNameTextBox
            // 
            this.lecturerNameTextBox.Location = new System.Drawing.Point(144, 117);
            this.lecturerNameTextBox.Name = "lecturerNameTextBox";
            this.lecturerNameTextBox.Size = new System.Drawing.Size(200, 22);
            this.lecturerNameTextBox.TabIndex = 0;
            // 
            // lecturerSurnameTextBox
            // 
            this.lecturerSurnameTextBox.Location = new System.Drawing.Point(144, 185);
            this.lecturerSurnameTextBox.Name = "lecturerSurnameTextBox";
            this.lecturerSurnameTextBox.Size = new System.Drawing.Size(200, 22);
            this.lecturerSurnameTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Dėstytojo (-os) vardas:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Dėstytojo (-os) pavardė:";
            // 
            // addLecturerButton
            // 
            this.addLecturerButton.Location = new System.Drawing.Point(175, 247);
            this.addLecturerButton.Name = "addLecturerButton";
            this.addLecturerButton.Size = new System.Drawing.Size(130, 30);
            this.addLecturerButton.TabIndex = 4;
            this.addLecturerButton.Text = "Pridėti dėstytoją";
            this.addLecturerButton.UseVisualStyleBackColor = true;
            this.addLecturerButton.Click += new System.EventHandler(this.addLecturerButton_Click);
            // 
            // AddLecturerWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 353);
            this.Controls.Add(this.addLecturerButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lecturerSurnameTextBox);
            this.Controls.Add(this.lecturerNameTextBox);
            this.Name = "AddLecturerWindow";
            this.Text = "AddLecturerWindow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lecturerNameTextBox;
        private System.Windows.Forms.TextBox lecturerSurnameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addLecturerButton;
    }
}