﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class LecturerWindow : LoggedInWindow
    {
        GroupsRepository grepository = new GroupsRepository();
        LecturesRepository lrepository = new LecturesRepository();
        Lecture lecture;

        public LecturerWindow(Lecturer lecturer) : base()
        {
            InitializeComponent();
            nameLabel.Text = lecturer.GetName();
            surnameLabel.Text = lecturer.GetSurname();

            lecturerLectureLabel.Visible = true;
            lectureLabel.Visible = true;

            lecture = lrepository.GetLecturerLecture(lecturer.LectureID);

            if (lecture != null)
            {
                lectureLabel.Text = lecture.Title;

                List<Group> groupsList = grepository.GetLecturerGroups(lecturer.LectureID);

                int buttonWidth = groupsLayoutPanel.Width - 10;

                foreach (Group group in groupsList)
                {
                    Button groupButton = new Button();
                    groupButton.Text = group.Title;
                    groupButton.Width = buttonWidth;
                    groupButton.Tag = group;
                    groupButton.Click += GroupButton_Click;
                    groupsLayoutPanel.Controls.Add(groupButton);
                }
            }
            else
                lectureLabel.Text = "-";
        }

        private void GroupButton_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Group group = (Group)button.Tag;

            studentsMarksLayoutPanel.Controls.Clear();

            foreach (Student student in group.studentsList)
            {
                LecturerMarksControl lmc = new LecturerMarksControl(student, lecture.LectureID);

                studentsMarksLayoutPanel.Controls.Add(lmc);
            }
        }
    }
}
