﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class RemoveLecturerWindow : Form
    {
        UsersRepository urepository = new UsersRepository();
        LecturersRepository lrepository = new LecturersRepository();
        List<Lecturer> lecturersList;
        int UserID;

        public RemoveLecturerWindow(List<Lecturer> lecturersList)
        {
            InitializeComponent();

            this.lecturersList = lecturersList;
        }

        private void removeLecturerButton_Click(object sender, EventArgs e)
        {
            bool lecturerFound = false;
            
            try
            {
                if (string.IsNullOrWhiteSpace(lecturerIDTextBox.Text))
                {
                    throw new Exception("Dėstytojo ID neįvestas.");
                }
                else
                {
                    foreach (Lecturer lecturer in lecturersList)
                    {
                        if (lecturer.LecturerID == int.Parse(lecturerIDTextBox.Text))
                        {
                            lecturerFound = true;
                            UserID = lecturer.UserID;
                        }
                    }

                    if (lecturerFound == true)
                    {
                        urepository.RemoveUser(UserID);
                        lrepository.RemoveLecturer(int.Parse(lecturerIDTextBox.Text));

                        MessageBox.Show("Dėstytojas ištrintas.");
                        this.Close();
                    }
                    else
                        throw new Exception("Dėstytojo su tokiu ID nėra.");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}