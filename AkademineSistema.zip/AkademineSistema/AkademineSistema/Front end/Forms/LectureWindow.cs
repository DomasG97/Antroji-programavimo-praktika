﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class LectureWindow : Form
    {
        LecturersRepository repository = new LecturersRepository();
        Lecturer lecturer;
        int LectureID;
        
        public LectureWindow(string title, int lectureid)
        {
            InitializeComponent();
            lectureLabel.Text = title;

            LectureID = lectureid;
            lecturer = repository.GetLecturerByLecture(lectureid);
            if (lecturer != null)
                lecturerLabel.Text = lecturer.Name + " " + lecturer.Surname;
            else
                lecturerLabel.Text = "-";
        }

        private void editLecturerButton_Click(object sender, EventArgs e)
        {
            EditLecturerWindow form = new EditLecturerWindow(LectureID, lecturer);
            form.ShowDialog();
            this.Close();
        }
    }
}
