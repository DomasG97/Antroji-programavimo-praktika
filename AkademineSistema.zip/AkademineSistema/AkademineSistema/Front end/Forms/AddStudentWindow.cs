﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AddStudentWindow : Form
    {
        UsersRepository urepository = new UsersRepository();
        StudentsRepository srepository = new StudentsRepository();
        int GroupID;
        
        public AddStudentWindow(int groupid)
        {
            InitializeComponent();

            GroupID = groupid;
        }

        private void addStudentButton_Click(object sender, EventArgs e)
        {
            urepository.AddUser(nameTextBox.Text, surnameTextBox.Text, "Studentas");
            User user = urepository.GetUser(nameTextBox.Text, surnameTextBox.Text);
            srepository.AddStudent(user.GetUserID(), GroupID, nameTextBox.Text, surnameTextBox.Text);

            MessageBox.Show("Studentas pridėtas.");
            this.Close();
        }
    }
}
