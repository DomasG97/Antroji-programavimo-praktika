﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class RemoveLectureWindow : Form
    {
        LecturesRepository repository = new LecturesRepository();
        List<Lecture> lecturesList;
        
        public RemoveLectureWindow(List<Lecture> lecturesList)
        {
            InitializeComponent();

            this.lecturesList = lecturesList;
        }

        private void deleteLectureButton_Click(object sender, EventArgs e)
        {
            bool lectureFound = false;
            
            try
            {
                if (string.IsNullOrWhiteSpace(lectureIDTextBox.Text))
                {
                    throw new Exception("Paskaitos ID neįvestas.");
                }
                else
                {
                    foreach (Lecture lecture in lecturesList)
                    {
                        if (lecture.LectureID == int.Parse(lectureIDTextBox.Text))
                            lectureFound = true;
                    }

                    if (lectureFound == true)
                    {
                        repository.RemoveLecture(int.Parse(lectureIDTextBox.Text));

                        MessageBox.Show("Paskaita ištrinta.");
                        this.Close();
                    }
                    else
                        throw new Exception("Paskaitos su tokiu ID nėra.");
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
