﻿namespace AkademineSistema
{
    partial class LecturerWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupsLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.studentsMarksLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // groupsLayoutPanel
            // 
            this.groupsLayoutPanel.AutoScroll = true;
            this.groupsLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.groupsLayoutPanel.Location = new System.Drawing.Point(12, 141);
            this.groupsLayoutPanel.Name = "groupsLayoutPanel";
            this.groupsLayoutPanel.Size = new System.Drawing.Size(200, 400);
            this.groupsLayoutPanel.TabIndex = 5;
            // 
            // studentsMarksLayoutPanel
            // 
            this.studentsMarksLayoutPanel.AutoScroll = true;
            this.studentsMarksLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.studentsMarksLayoutPanel.Location = new System.Drawing.Point(218, 141);
            this.studentsMarksLayoutPanel.Name = "studentsMarksLayoutPanel";
            this.studentsMarksLayoutPanel.Size = new System.Drawing.Size(752, 400);
            this.studentsMarksLayoutPanel.TabIndex = 6;
            // 
            // LecturerWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.studentsMarksLayoutPanel);
            this.Controls.Add(this.groupsLayoutPanel);
            this.Name = "LecturerWindow";
            this.Text = "LecturerWindow";
            this.Controls.SetChildIndex(this.nameLabel, 0);
            this.Controls.SetChildIndex(this.surnameLabel, 0);
            this.Controls.SetChildIndex(this.logoutButton, 0);
            this.Controls.SetChildIndex(this.groupsLayoutPanel, 0);
            this.Controls.SetChildIndex(this.studentsMarksLayoutPanel, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel groupsLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel studentsMarksLayoutPanel;
    }
}