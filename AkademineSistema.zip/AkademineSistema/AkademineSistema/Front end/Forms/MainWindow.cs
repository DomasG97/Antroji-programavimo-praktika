﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            UsersRepository repository = new UsersRepository();

            try
            {
                User user = repository.GetUser(usernameTextBox.Text, passwordTextBox.Text);

                if (user.GetStatus() == "Adminas")
                {
                    Admin admin = repository.GetAdmin(user.GetUserID());
                    AdminWindow form = new AdminWindow(admin);
                    this.Hide();
                    form.ShowDialog();
                    this.Show();
                    usernameTextBox.Clear();
                    passwordTextBox.Clear();
                }
                if (user.GetStatus() == "Destytojas")
                {
                    Lecturer lecturer = repository.GetLecturer(user.GetUserID());
                    LecturerWindow form = new LecturerWindow(lecturer);
                    this.Hide();
                    form.ShowDialog();
                    this.Show();
                    usernameTextBox.Clear();
                    passwordTextBox.Clear();
                }
                if (user.GetStatus() == "Studentas")
                {
                    Student student = repository.GetStudent(user.GetUserID());
                    StudentWindow form = new StudentWindow(student);
                    this.Hide();
                    form.ShowDialog();
                    this.Show();
                    usernameTextBox.Clear();
                    passwordTextBox.Clear();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
