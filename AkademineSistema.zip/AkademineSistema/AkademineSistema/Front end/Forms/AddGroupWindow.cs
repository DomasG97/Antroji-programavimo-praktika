﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AddGroupWindow : Form
    {
        GroupsRepository repository = new GroupsRepository();
        List<Group> groupsList;
        
        public AddGroupWindow(List<Group> groupsList)
        {
            InitializeComponent();
            this.groupsList = groupsList;
        }

        private void addGroupButton_Click(object sender, EventArgs e)
        {
            bool groupExists = false;
            
            try
            {
                foreach(Group group in groupsList)
                {
                    if (newGroupTextBox.Text == group.Title)
                        groupExists = true;
                }

                if (groupExists == true)
                    throw new Exception("Tokia grupė jau yra.");
                else if(string.IsNullOrWhiteSpace(newGroupTextBox.Text))
                    throw new Exception("Grupė neįvesta.");
                else
                {
                    repository.AddGroup(newGroupTextBox.Text);
                    MessageBox.Show("Grupė buvo pridėta.");
                    this.Close();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
