﻿namespace AkademineSistema
{
    partial class AdminWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupsLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addGroupButton = new System.Windows.Forms.Button();
            this.removeGroupButton = new System.Windows.Forms.Button();
            this.lecturesLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.studentsLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.removeLectureButton = new System.Windows.Forms.Button();
            this.addLectureButton = new System.Windows.Forms.Button();
            this.addStudentButton = new System.Windows.Forms.Button();
            this.lecturersLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.removeLecturerButton = new System.Windows.Forms.Button();
            this.addLecturerButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // groupsLayoutPanel
            // 
            this.groupsLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.groupsLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.groupsLayoutPanel.Location = new System.Drawing.Point(268, 141);
            this.groupsLayoutPanel.Name = "groupsLayoutPanel";
            this.groupsLayoutPanel.Size = new System.Drawing.Size(200, 400);
            this.groupsLayoutPanel.TabIndex = 5;
            // 
            // addGroupButton
            // 
            this.addGroupButton.Location = new System.Drawing.Point(294, 69);
            this.addGroupButton.Name = "addGroupButton";
            this.addGroupButton.Size = new System.Drawing.Size(150, 30);
            this.addGroupButton.TabIndex = 6;
            this.addGroupButton.Text = "Pridėti grupę";
            this.addGroupButton.UseVisualStyleBackColor = true;
            this.addGroupButton.Click += new System.EventHandler(this.addGroupButton_Click);
            // 
            // removeGroupButton
            // 
            this.removeGroupButton.Location = new System.Drawing.Point(294, 105);
            this.removeGroupButton.Name = "removeGroupButton";
            this.removeGroupButton.Size = new System.Drawing.Size(150, 30);
            this.removeGroupButton.TabIndex = 7;
            this.removeGroupButton.Text = "Ištrinti grupę";
            this.removeGroupButton.UseVisualStyleBackColor = true;
            this.removeGroupButton.Click += new System.EventHandler(this.removeGroupButton_Click);
            // 
            // lecturesLayoutPanel
            // 
            this.lecturesLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lecturesLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.lecturesLayoutPanel.Location = new System.Drawing.Point(474, 141);
            this.lecturesLayoutPanel.Name = "lecturesLayoutPanel";
            this.lecturesLayoutPanel.Size = new System.Drawing.Size(250, 400);
            this.lecturesLayoutPanel.TabIndex = 9;
            // 
            // studentsLayoutPanel
            // 
            this.studentsLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.studentsLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.studentsLayoutPanel.Location = new System.Drawing.Point(731, 141);
            this.studentsLayoutPanel.Name = "studentsLayoutPanel";
            this.studentsLayoutPanel.Size = new System.Drawing.Size(239, 400);
            this.studentsLayoutPanel.TabIndex = 10;
            // 
            // removeLectureButton
            // 
            this.removeLectureButton.Location = new System.Drawing.Point(522, 105);
            this.removeLectureButton.Name = "removeLectureButton";
            this.removeLectureButton.Size = new System.Drawing.Size(150, 30);
            this.removeLectureButton.TabIndex = 12;
            this.removeLectureButton.Text = "Ištrinti paskaitą";
            this.removeLectureButton.UseVisualStyleBackColor = true;
            this.removeLectureButton.Visible = false;
            this.removeLectureButton.Click += new System.EventHandler(this.removeLectureButton_Click);
            // 
            // addLectureButton
            // 
            this.addLectureButton.Location = new System.Drawing.Point(522, 69);
            this.addLectureButton.Name = "addLectureButton";
            this.addLectureButton.Size = new System.Drawing.Size(150, 30);
            this.addLectureButton.TabIndex = 11;
            this.addLectureButton.Text = "Pridėti paskaitą";
            this.addLectureButton.UseVisualStyleBackColor = true;
            this.addLectureButton.Visible = false;
            this.addLectureButton.Click += new System.EventHandler(this.addLectureButton_Click);
            // 
            // addStudentButton
            // 
            this.addStudentButton.Location = new System.Drawing.Point(775, 105);
            this.addStudentButton.Name = "addStudentButton";
            this.addStudentButton.Size = new System.Drawing.Size(150, 30);
            this.addStudentButton.TabIndex = 13;
            this.addStudentButton.Text = "Pridėti studentą";
            this.addStudentButton.UseVisualStyleBackColor = true;
            this.addStudentButton.Visible = false;
            this.addStudentButton.Click += new System.EventHandler(this.addStudentButton_Click);
            // 
            // lecturersLayoutPanel
            // 
            this.lecturersLayoutPanel.AutoScroll = true;
            this.lecturersLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lecturersLayoutPanel.Location = new System.Drawing.Point(13, 141);
            this.lecturersLayoutPanel.Name = "lecturersLayoutPanel";
            this.lecturersLayoutPanel.Size = new System.Drawing.Size(249, 400);
            this.lecturersLayoutPanel.TabIndex = 14;
            // 
            // removeLecturerButton
            // 
            this.removeLecturerButton.Location = new System.Drawing.Point(64, 105);
            this.removeLecturerButton.Name = "removeLecturerButton";
            this.removeLecturerButton.Size = new System.Drawing.Size(150, 30);
            this.removeLecturerButton.TabIndex = 15;
            this.removeLecturerButton.Text = "Ištrinti dėstytoją";
            this.removeLecturerButton.UseVisualStyleBackColor = true;
            this.removeLecturerButton.Click += new System.EventHandler(this.removeLecturerButton_Click);
            // 
            // addLecturerButton
            // 
            this.addLecturerButton.Location = new System.Drawing.Point(64, 69);
            this.addLecturerButton.Name = "addLecturerButton";
            this.addLecturerButton.Size = new System.Drawing.Size(150, 30);
            this.addLecturerButton.TabIndex = 16;
            this.addLecturerButton.Text = "Pridėti dėstytoją";
            this.addLecturerButton.UseVisualStyleBackColor = true;
            this.addLecturerButton.Click += new System.EventHandler(this.addLecturerButton_Click);
            // 
            // AdminWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.addLecturerButton);
            this.Controls.Add(this.removeLecturerButton);
            this.Controls.Add(this.lecturersLayoutPanel);
            this.Controls.Add(this.addStudentButton);
            this.Controls.Add(this.removeLectureButton);
            this.Controls.Add(this.addLectureButton);
            this.Controls.Add(this.studentsLayoutPanel);
            this.Controls.Add(this.lecturesLayoutPanel);
            this.Controls.Add(this.removeGroupButton);
            this.Controls.Add(this.addGroupButton);
            this.Controls.Add(this.groupsLayoutPanel);
            this.Name = "AdminWindow";
            this.Text = "AdminWindow";
            this.Controls.SetChildIndex(this.lectureLabel, 0);
            this.Controls.SetChildIndex(this.lecturerLectureLabel, 0);
            this.Controls.SetChildIndex(this.nameLabel, 0);
            this.Controls.SetChildIndex(this.surnameLabel, 0);
            this.Controls.SetChildIndex(this.logoutButton, 0);
            this.Controls.SetChildIndex(this.groupsLayoutPanel, 0);
            this.Controls.SetChildIndex(this.addGroupButton, 0);
            this.Controls.SetChildIndex(this.removeGroupButton, 0);
            this.Controls.SetChildIndex(this.lecturesLayoutPanel, 0);
            this.Controls.SetChildIndex(this.studentsLayoutPanel, 0);
            this.Controls.SetChildIndex(this.addLectureButton, 0);
            this.Controls.SetChildIndex(this.removeLectureButton, 0);
            this.Controls.SetChildIndex(this.addStudentButton, 0);
            this.Controls.SetChildIndex(this.lecturersLayoutPanel, 0);
            this.Controls.SetChildIndex(this.removeLecturerButton, 0);
            this.Controls.SetChildIndex(this.addLecturerButton, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel groupsLayoutPanel;
        private System.Windows.Forms.Button addGroupButton;
        private System.Windows.Forms.Button removeGroupButton;
        private System.Windows.Forms.FlowLayoutPanel lecturesLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel studentsLayoutPanel;
        private System.Windows.Forms.Button removeLectureButton;
        private System.Windows.Forms.Button addLectureButton;
        private System.Windows.Forms.Button addStudentButton;
        private System.Windows.Forms.FlowLayoutPanel lecturersLayoutPanel;
        private System.Windows.Forms.Button removeLecturerButton;
        private System.Windows.Forms.Button addLecturerButton;
    }
}