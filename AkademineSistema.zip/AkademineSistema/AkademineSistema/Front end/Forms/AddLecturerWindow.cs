﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class AddLecturerWindow : Form
    {
        UsersRepository urepository = new UsersRepository();
        LecturersRepository lrepository = new LecturersRepository();

        public AddLecturerWindow()
        {
            InitializeComponent();
        }

        private void addLecturerButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(lecturerNameTextBox.Text) || string.IsNullOrWhiteSpace(lecturerSurnameTextBox.Text))
                {
                    MessageBox.Show("Tuščių laukų būti negali.");
                }
                else
                {
                    urepository.AddUser(lecturerNameTextBox.Text, lecturerSurnameTextBox.Text, "Destytojas");
                    User user = urepository.GetUser(lecturerNameTextBox.Text, lecturerSurnameTextBox.Text);
                    lrepository.AddLecturer(user.GetUserID(), lecturerNameTextBox.Text, lecturerSurnameTextBox.Text);

                    MessageBox.Show("Dėstytojas pridėtas.");
                    this.Close();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
