﻿namespace AkademineSistema
{
    partial class LoggedInWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.surnameLabel = new System.Windows.Forms.Label();
            this.logoutButton = new System.Windows.Forms.Button();
            this.lectureLabel = new System.Windows.Forms.Label();
            this.lecturerLectureLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(13, 13);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(77, 17);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "name label";
            // 
            // surnameLabel
            // 
            this.surnameLabel.AutoSize = true;
            this.surnameLabel.Location = new System.Drawing.Point(13, 34);
            this.surnameLabel.Name = "surnameLabel";
            this.surnameLabel.Size = new System.Drawing.Size(97, 17);
            this.surnameLabel.TabIndex = 1;
            this.surnameLabel.Text = "surname label";
            // 
            // logoutButton
            // 
            this.logoutButton.Location = new System.Drawing.Point(870, 12);
            this.logoutButton.Name = "logoutButton";
            this.logoutButton.Size = new System.Drawing.Size(100, 30);
            this.logoutButton.TabIndex = 4;
            this.logoutButton.Text = "Atsijungti";
            this.logoutButton.UseVisualStyleBackColor = true;
            this.logoutButton.Click += new System.EventHandler(this.logoutButton_Click);
            // 
            // lectureLabel
            // 
            this.lectureLabel.AutoSize = true;
            this.lectureLabel.Location = new System.Drawing.Point(146, 70);
            this.lectureLabel.Name = "lectureLabel";
            this.lectureLabel.Size = new System.Drawing.Size(85, 17);
            this.lectureLabel.TabIndex = 5;
            this.lectureLabel.Text = "lecture label";
            this.lectureLabel.Visible = false;
            // 
            // lecturerLectureLabel
            // 
            this.lecturerLectureLabel.AutoSize = true;
            this.lecturerLectureLabel.Location = new System.Drawing.Point(13, 70);
            this.lecturerLectureLabel.Name = "lecturerLectureLabel";
            this.lecturerLectureLabel.Size = new System.Drawing.Size(127, 17);
            this.lecturerLectureLabel.TabIndex = 6;
            this.lecturerLectureLabel.Text = "Dėstomas dalykas:";
            this.lecturerLectureLabel.Visible = false;
            // 
            // LoggedInWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.lecturerLectureLabel);
            this.Controls.Add(this.lectureLabel);
            this.Controls.Add(this.logoutButton);
            this.Controls.Add(this.surnameLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "LoggedInWindow";
            this.Text = "LoggedInWindow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label nameLabel;
        public System.Windows.Forms.Label surnameLabel;
        public System.Windows.Forms.Button logoutButton;
        protected System.Windows.Forms.Label lectureLabel;
        protected System.Windows.Forms.Label lecturerLectureLabel;
    }
}