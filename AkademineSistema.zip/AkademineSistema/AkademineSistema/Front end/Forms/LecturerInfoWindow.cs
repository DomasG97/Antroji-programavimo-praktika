﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class LecturerInfoWindow : Form
    {
        LecturesRepository repository = new LecturesRepository();
        Lecture lecture;
        
        public LecturerInfoWindow(Lecturer lecturer)
        {
            InitializeComponent();

            lecturerNameLabel.Text = lecturer.Name;
            lecturerSurnameLabel.Text = lecturer.Surname;

            lecture = repository.GetLecturerLecture(lecturer.LectureID);

            if (lecture != null)
                lecturerLectureLabel.Text = lecture.Title;
            else
                lecturerLectureLabel.Text = "-";
        }
    }
}
