﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkademineSistema
{
    public partial class RemoveGroupWindow : Form
    {
        GroupsRepository repository = new GroupsRepository();
        List<Group> groupsList;
        
        public RemoveGroupWindow(List<Group> groupsList)
        {
            InitializeComponent();

            this.groupsList = groupsList;
        }

        private void removeGroupButton_Click(object sender, EventArgs e)
        {
            bool groupFound = false;

            try
            {
                foreach (Group group in groupsList)
                {
                    if (group.Title == groupTextBox.Text)
                        groupFound = true;
                }

                if (groupFound == true)
                {
                    repository.RemoveGroup(groupTextBox.Text);

                    MessageBox.Show("Grupė ištrinta.");
                    this.Close();
                }
                else if(string.IsNullOrWhiteSpace(groupTextBox.Text))
                    throw new Exception("Grupė neįvesta.");
                else
                    throw new Exception("Tokios grupės nėra.");
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}
