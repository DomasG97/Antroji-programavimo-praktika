﻿namespace AkademineSistema
{
    partial class LecturerInfoWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lecturerNameLabel = new System.Windows.Forms.Label();
            this.lecturerSurnameLabel = new System.Windows.Forms.Label();
            this.lecturerLectureLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lecturerNameLabel
            // 
            this.lecturerNameLabel.AutoSize = true;
            this.lecturerNameLabel.Location = new System.Drawing.Point(205, 72);
            this.lecturerNameLabel.Name = "lecturerNameLabel";
            this.lecturerNameLabel.Size = new System.Drawing.Size(95, 17);
            this.lecturerNameLabel.TabIndex = 0;
            this.lecturerNameLabel.Text = "lecturer name";
            // 
            // lecturerSurnameLabel
            // 
            this.lecturerSurnameLabel.AutoSize = true;
            this.lecturerSurnameLabel.Location = new System.Drawing.Point(205, 109);
            this.lecturerSurnameLabel.Name = "lecturerSurnameLabel";
            this.lecturerSurnameLabel.Size = new System.Drawing.Size(115, 17);
            this.lecturerSurnameLabel.TabIndex = 1;
            this.lecturerSurnameLabel.Text = "lecturer surname";
            // 
            // lecturerLectureLabel
            // 
            this.lecturerLectureLabel.AutoSize = true;
            this.lecturerLectureLabel.Location = new System.Drawing.Point(208, 190);
            this.lecturerLectureLabel.Name = "lecturerLectureLabel";
            this.lecturerLectureLabel.Size = new System.Drawing.Size(103, 17);
            this.lecturerLectureLabel.TabIndex = 2;
            this.lecturerLectureLabel.Text = "lecturer lecture";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(142, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Vardas:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Pavardė:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Dėstomas dalykas:";
            // 
            // LecturerInfoWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 353);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lecturerLectureLabel);
            this.Controls.Add(this.lecturerSurnameLabel);
            this.Controls.Add(this.lecturerNameLabel);
            this.Name = "LecturerInfoWindow";
            this.Text = "LecturerInfoWindow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lecturerNameLabel;
        private System.Windows.Forms.Label lecturerSurnameLabel;
        private System.Windows.Forms.Label lecturerLectureLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}